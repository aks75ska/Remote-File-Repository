#pragma once
#ifndef BROWSE_H
#define BROWSE_H
/////////////////////////////////////////////////////////////////////
// Browse.h - provides means to browse source code packages.       //
// ver 1.0                                                         //
// Akshay Goyal, CSE687 - Object Oriented Design, Spring 2018      //
/////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* this package provides one class Browse
* Browse implements the browsing of a file structure in windows
* - it takes a list of file paths, finds their corresponding packages
*  and print details and contents of those packages on the console


* Required Files:
* ---------------
- no required files
*
* Maintenance History:
* --------------------
* ver 1.0 : 2 Mar 2018
*/

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>

using namespace std;

namespace BrowseClasses 
{
	class Browse 
	{
		public:
			using PackagePath = std::string;
			using FileName = std::string;
			using FilePaths = std::vector<std::string>;
			using PackagePaths = std::vector<std::string>;

			//we will use this method to input file paths returned from DB Query and getting the corresponding package names
			PackagePaths getPackagePathsFromFile(const FilePaths& filePaths);
			//this method will print all file versions and their details for a given package
			void printPackageHistory(const PackagePath& packagePath);
			//this method will print the file text (10 lines) of all files in a package one by one (we will print all the versions)
			void printFullPackageText(const PackagePath& packagePath);

		private:
			
	};

}

#endif