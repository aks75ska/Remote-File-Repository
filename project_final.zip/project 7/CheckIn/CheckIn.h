#pragma once
#ifndef CHECKIN_H
#define CHECKIN_H
/////////////////////////////////////////////////////////////////////
// CheckIn.h - provides means to check-in source code packages.    //
// ver 1.0                                                         //
// Akshay Goyal, CSE687 - Object Oriented Design, Spring 2018      //
/////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* It contains one class Checkin
* CheckIn implements checking in of files in a Respository
* It takes a DBCore object and updates it after moving the files of a given packge
* to their appropriate place in the file repository


* Required Files:
* ---------------
../DbCore/DbCore.h, ../Payloads/Payloads.h
*
* Maintenance History:
* --------------------
* ver 1.0 : 1 Mar 2018
*/

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>

#include "../DbCore/DbCore.h"
#include "../Payloads/Payloads.h"

using namespace std;
using namespace NoSqlDb;
using namespace Payloads;

namespace CheckInClasses 
{

	class CheckIn 
	{
		public:
			using PackageName = std::string;
			using DependantPackages = std::vector<std::string>;
			using AuthorName = std::string;
			using PackagePath = std::string;

			//this method will checkin a package taking its path, dependant packages and author name as parameters
			bool checkInPackage(DbCore<FileRepositoryPayload>& db, const PackageName& packageName, const DependantPackages& dependantPackages, const AuthorName& authorName, const PackagePath& packagePath);

		private:
			PackageName packageName_;
			DependantPackages dependantPackages_;
			AuthorName authorName_;
			PackagePath packagePath_;
			bool checkDependencies(DbCore<FileRepositoryPayload>& db, DependantPackages& dependantPackages);
			bool updateInfoCopyAndDeleteFiles(DbCore<FileRepositoryPayload>& db);
	};

}
#endif