#pragma once
#ifndef PC_H
#define PC_H
/////////////////////////////////////////////////////////////////////
// PackageC.h - provides means to test demo repository.            //
// ver 1.0                                                         //
// Akshay Goyal, CSE687 - Object Oriented Design, Spring 2018      //
/////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------

* Required Files:
* ---------------

*
* Maintenance History:
* --------------------
* ver 1.0 : 1 Mar 2018
*/

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>

using namespace std;

namespace CheckOutClasses
{

	class CheckOut 
	{
		public:
			using PackageName = std::string;
			using SourcePath = std::string;
			using DestinationPath = std::string;
			bool checkoutPackage(const SourcePath& sourcePath, const PackageName& packageName, const DestinationPath& destinationPath);
	};

}
#endif