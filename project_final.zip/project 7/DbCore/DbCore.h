#pragma once
/////////////////////////////////////////////////////////////////////
// DbCore.h - Implements NoSql database prototype                  //
// ver 1.0                                                         //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2018       //
/////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* This package provides two classes:
* - DbCore implements core NoSql database operations, but does not
*   provide editing, querying, or persisting.  Those are left as
*   exercises for students.
* - DbElement provides the value part of our key-value database.
*   It contains fields for name, description, date, child collection
*   and a payload field of the template type. 
* The package also provides functions for displaying:
* - set of all database keys
* - database elements
* - all records in the database
* - function for augmenting the database from an input xml file
* - function for generating an xml file from the database

* Required Files:
* ---------------
* DbCore.h, DbCore.cpp
* DateTime.h, DateTime.cpp
* Utilities.h, Utilities.cpp
* XmlDocument.h, XmlDocument.cpp
*
* Maintenance History:
* --------------------
* ver 1.0 : 10 Jan 2018
* ver 1.1 : 2 Feb 2018 - Akshay Goyal
*/

#include <unordered_map>
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include "../DateTime/DateTime.h"
#include "../XmlDocument/XmlDocument/XmlDocument.h"
#include "../XmlDocument/XmlElement/XmlElement.h"
#include <fstream>

#include <sstream>
#include <algorithm>
#include <iterator>

using namespace XmlProcessing;
using namespace std;

namespace NoSqlDb
{

  /////////////////////////////////////////////////////////////////////
  // DbElement class
  // - provides the value part of a NoSql key-value database

  template<typename T>
  class DbElement
  {
  public:
    using Key = std::string;
    using Children = std::vector<Key>;

    // methods to get and set DbElement fields

    std::string& name() { return name_; }
    std::string name() const { return name_; }
    void name(const std::string& name) { name_ = name; }

    std::string& descrip() { return descrip_; }
    std::string descrip() const { return descrip_; }
    void descrip(const std::string& name) { descrip_ = name; }
    
    DateTime& dateTime() { return dateTime_; }
    DateTime dateTime() const { return dateTime_; }
    void dateTime(const DateTime& dateTime) { dateTime_ = dateTime; }

    Children& children() { return children_; }
    Children children() const { return children_; }
    void children(const Children& children) { children_ = children; }

    T& payLoad() { return payLoad_; }
    T payLoad() const { return payLoad_; }
    void payLoad(const T& payLoad) { payLoad_ = payLoad; }

  private:
    std::string name_;
    std::string descrip_;
    DateTime dateTime_;
    Children children_;
    T payLoad_;
  };

  /////////////////////////////////////////////////////////////////////
  // DbCore class
  // - provides core NoSql db operations
  // - does not provide editing, querying, or persistance operations

  template <typename T>
  class DbCore
  {
  public:
    using Key = std::string;
    using Keys = std::vector<Key>;
    using Children = Keys;
    using DbStore = std::unordered_map<Key,DbElement<T>>;
    using iterator = typename DbStore::iterator;
	using Sptr = std::shared_ptr<AbstractXmlElement>;

    // methods to access database elements

    Keys keys();
    bool contains(const Key& key);
    size_t size();
    DbElement<T>& operator[](const Key& key);
    DbElement<T> operator[](const Key& key) const;
    typename iterator begin() { return dbStore_.begin(); }
    typename iterator end() { return dbStore_.end(); }

	//methods to add and remove key/value pairs
	bool addPair(const Key& key, const DbElement<T>& value);
	bool deletePair(const Key& key);

	//methods to edit values of the database
	bool addChildKey(const Key& parent, const Key& child);
	bool deleteChildKey(const Key& parent, const Key& child);
	bool updateName(const Key& key, const std::string& name);
	bool updateDescription(const Key& key, const std::string& description);
	bool updateDateTime(const Key& key, const DateTime& dateTime);
	bool updateValue(const Key& key, const DbElement<T>& value);

	//methods for creating xml from the given db
	bool generateXMLFile(std::string fileName);

	//method to create database with a given xml file
	bool keysFromXml(std::string fileName);

    // methods to get and set the private database hash-map storage

    DbStore& dbStore() { return dbStore_; }
    DbStore dbStore() const { return dbStore_; }
    void dbStore(const DbStore& dbStore) { dbStore_ = dbStore; }
  
  private:
    DbStore dbStore_;
  };

  /////////////////////////////////////////////////////////////////////
  // DbCore<T> methods
  
  //----<method to add keys from an xml file>----
  template<typename T>
  bool DbCore<T>::keysFromXml(std::string fileName)
  {
	  std::string output = "";
	  std::string data = "";
	  ifstream infile;
	  infile.open(fileName);
	  if (!infile) {
		  cerr << "Unable to open file";
	  }
	  else 
	  {
		  while (!infile.eof()) {
			  getline(infile, output);
			  data = data + output + "\n";
		  }
		  infile.close();
	  }

	  //cout << data << endl;

	  XmlDocument newXDoc(data, XmlDocument::str);
	  std::vector<Sptr> found = newXDoc.element("NoSqlDb").select();
	  std::vector<Sptr> records = newXDoc.descendents("dbRecord").select();
	  for (auto pRecord : records)
	  {
		  Key key;
		  DbElement<T> elem;
		  std::vector<Sptr> pChildren = pRecord->children();
		  for (auto pChild : pChildren)
		  {
			  // record's children are key and value

			  if (pChild->tag() == "key")
			  {
				  // get value of TextElement child
				  key = pChild->children()[0]->value();
			  }
			  else
			  {
				  // value represents a DbElement<T> with its child payload and its attributes

				  AbstractXmlElement::Attributes attribs = pChild->attributes();
				  elem.name(attribs[0].second);
				  elem.descrip(attribs[1].second);
				  std::string dateTimeString = attribs[2].second;
				  std::string childrenString = attribs[3].second;
				  DateTime dts = DateTime(dateTimeString);
				  elem.dateTime(dts);
				  istringstream iss(childrenString);
				  vector<string> tokens{ istream_iterator<string>{iss}, istream_iterator<string>{} };
				  elem.children(tokens);

				  std::vector<Sptr> pValueChildren = pChild->children();

				  for (auto pValueChild : pValueChildren)
				  {
					  if (pValueChild->tag() == "payload")
					  {
						  // get value of TextElement child
						  elem.payLoad(pValueChild->children()[0]->value());
					  }
				  }
			  }
		  }
		  addPair(key, elem);
	  }

	  return true;
  }

  //----<function to generate xml file from current db>----
  template<typename T>
  bool DbCore<T>::generateXMLFile(std::string fileName)
  {
	  //first, creating the content as a string
	  Sptr pDb = makeTaggedElement("NoSqlDb");
	  pDb->addAttrib("type", "DbCore");
	  Sptr pDocElem = makeDocElement(pDb);
	  XmlDocument xDoc(pDocElem);
	  for (auto item : dbStore_)
	  {
		  Sptr pRecord = makeTaggedElement("dbRecord");
		  pDb->addChild(pRecord);
		  Sptr pKey = makeTaggedElement("key", item.first);
		  pRecord->addChild(pKey);

		  string listOfChildren = "";
		  for (auto child : item.second.children()) 
		  {
			  listOfChildren.append(child+" ");
		  }

		  Sptr pValue = makeTaggedElement("value");
		  pValue->addAttrib("name", item.second.name());
		  pValue->addAttrib("description", item.second.descrip());
		  pValue->addAttrib("date_time", item.second.dateTime());
		  pValue->addAttrib("children_keys", listOfChildren);
		  pRecord->addChild(pValue);
		  Sptr pPayload = makeTaggedElement("payload", item.second.payLoad());
		  pValue->addChild(pPayload);
		  
	  }
	  std::string Xml = xDoc.toString();
	  
	  ofstream outfile;
	  outfile.open(fileName);
	  outfile << Xml << endl;
	  outfile.close();
	  return true;
  }

  //----<function to add a child key to a parent key>----
  template<typename T>
  bool DbCore<T>::addChildKey(const Key& parent, const Key& child)
  {
	  if (contains(parent))
	  {
		  dbStore_[parent].children().push_back(child);
		  return true;
	  }
	  else
	  {
		  return false;
	  }
  }

  //----<function to delete a child key from a parent key>----
  template<typename T>
  bool DbCore<T>::deleteChildKey(const Key& parent, const Key& child)
  {
	  if (contains(parent) && contains(child))
	  {
		  //dbStore_[parent].children().erase(child);
		  ptrdiff_t pos = std::find(dbStore_[parent].children().begin(), dbStore_[parent].children().end(), child) - dbStore_[parent].children().begin();
		  if (pos != -1) 
		  {
			  dbStore_[parent].children().erase(dbStore_[parent].children().begin() + pos);
			  return true;
		  }
		  return false;
	  }
	  else
	  {
		  return false;
	  }
  }

  //----<function to update name metadata of a key>----
  template<typename T>
  bool DbCore<T>::updateName(const Key& key, const std::string& name)
  {
	  if (contains(key))
	  {
		  dbStore_[key].name(name);
		  return true;
	  }
	  else
	  {
		  return false;
	  }
  }

  //----<function to update description metadata of a key>----
  template<typename T>
  bool DbCore<T>::updateDescription(const Key& key, const std::string& description)
  {
	  if (contains(key))
	  {
		  dbStore_[key].descrip(description);
		  return true;
	  }
	  else
	  {
		  return false;
	  }
  }

  //----<function to update datetime metadata of a key>----
  template<typename T>
  bool DbCore<T>::updateDateTime(const Key& key, const DateTime& dateTime)
  {
	  if (contains(key))
	  {
		  dbStore_[key].dateTime(dateTime);
		  return true;
	  }
	  else
	  {
		  return false;
	  }
  }

  //----<function to replace value of a key>----
  template<typename T>
  bool DbCore<T>::updateValue(const Key& key, const DbElement<T>& value)
  {
	  if (contains(key))
	  {
		  dbStore_[key] = value;
		  return true;
	  }
	  else
	  {
		  return false;
	  }
  }

  //----<function to add a key value pair to the databse>----
  template<typename T>
  bool DbCore<T>::addPair(const Key& key, const DbElement<T>& value)
  {
	  if (!contains(key)) 
	  {
		  dbStore_[key] = value;
		  return true;
	  }
	  else
	  {
		  return false;
	  }
  }

  //----<function to delete a key value pair to the databse>----
  template<typename T>
  bool DbCore<T>::deletePair(const Key& key)
  {
	  if (contains(key))
	  {
		  dbStore_.erase(key);
		  return true;
	  }
	  else 
	  {
		  return false;
	  }
  }

  //----< does db contain this key? >----------------------------------

  template<typename T>
  bool DbCore<T>::contains(const Key& key)
  {
    iterator iter = dbStore_.find(key);
    return iter != dbStore_.end();
  }
  //----< returns current key set for db >-----------------------------

  template<typename T>
  typename DbCore<T>::Keys DbCore<T>::keys()
  {
    DbCore<T>::Keys dbKeys;
    DbStore& dbs = dbStore();
    size_t size = dbs.size();
    dbKeys.reserve(size);
    for (auto item : dbs)
    {
      dbKeys.push_back(item.first);
    }
    return dbKeys;
  }
  //----< return number of db elements >-------------------------------

  template<typename T>
  size_t DbCore<T>::size()
  {
    return dbStore_.size();
  }
  //----< extracts value from db with key >----------------------------
  /*
  *  - indexes non-const db objects
  */
  template<typename T>
  DbElement<T>& DbCore<T>::operator[](const Key& key)
  {
    if (!contains(key))
    {
      dbStore_[key] = DbElement<T>();
    }
    return dbStore_[key];
  }
  //----< extracts value from db with key >----------------------------
  /*
  *  - indexes const db objects
  */
  template<typename T>
  DbElement<T> DbCore<T>::operator[](const Key& key) const
  {
    if (!contains(key))
    {
      dbStore_[key] = DbElement<T>();
    }
    return dbStore_[key];
  }
  
  /////////////////////////////////////////////////////////////////////
  // display functions

  //----< display database key set >-----------------------------------

  template<typename T>
  void showKeys(DbCore<T>& db, std::ostream& out = std::cout)
  {
    out << "\n  ";
    for (auto key : db.keys())
    {
      out << key << " ";
    }
  }
  //----< show record header items >-----------------------------------

  inline void showHeader(std::ostream& out = std::cout)
  {
    out << "\n  ";
    out << std::setw(26) << std::left << "DateTime";
    out << std::setw(10) << std::left << "Name";
    out << std::setw(25) << std::left << "Description";
    out << std::setw(25) << std::left << "Payload";
    out << "\n  ";
    out << std::setw(26) << std::left << "------------------------";
    out << std::setw(10) << std::left << "--------";
    out << std::setw(25) << std::left << "-----------------------";
    out << std::setw(25) << std::left << "-----------------------";
  }
  //----< display DbElements >-----------------------------------------

  template<typename T>
  void showElem(const DbElement<T>& el, std::ostream& out = std::cout)
  {
    out << "\n  ";
    out << std::setw(26) << std::left << std::string(el.dateTime());
    out << std::setw(10) << std::left << el.name();
    out << std::setw(25) << std::left << el.descrip();
    out << std::setw(25) << std::left << el.payLoad();
    typename DbElement<T>::Children children = el.children();
    if (children.size() > 0)
    {
      out << "\n    child keys: ";
      for (auto key : children)
      {
        out << " " << key;
      }
    }
  }
  //----< display all records in database >----------------------------

  template<typename T>
  void showDb(const DbCore<T>& db, std::ostream& out = std::cout)
  {
    //out << "\n  ";
    //out << std::setw(26) << std::left << "DateTime";
    //out << std::setw(10) << std::left << "Name";
    //out << std::setw(25) << std::left << "Description";
    //out << std::setw(25) << std::left << "Payload";
    //out << "\n  ";
    //out << std::setw(26) << std::left << "------------------------";
    //out << std::setw(10) << std::left << "--------";
    //out << std::setw(25) << std::left << "-----------------------";
    //out << std::setw(25) << std::left << "-----------------------";
    showHeader(out);
    typename DbCore<T>::DbStore dbs = db.dbStore();
    for (auto item : dbs)
    {
      showElem(item.second, out);
    }
  }
}
