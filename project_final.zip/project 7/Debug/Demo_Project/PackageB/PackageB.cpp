/////////////////////////////////////////////////////////////////////
// PackageB.cpp - provides means to test demo repository.          //
// ver 1.0                                                         //
// Akshay Goyal, CSE687 - Object Oriented Design, Spring 2018      //
/////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Browse.h"

#include "../FileSystemDemo/FileSystem.h"

using namespace std;
using namespace FileSystem;
using namespace BrowseClasses;

void title(const std::string& title, char ch = '=')
{
	std::cout << "\n  " << title;
	std::cout << "\n " << std::string(title.size() + 2, ch);
}

Browse::PackagePaths Browse::getPackagePathsFromFile(const FilePaths& filePaths)
{
	std::vector<std::string> packageNames;
	
	for (auto file : filePaths)
	{
		std::size_t found = file.find_last_of("/");
		std::string packagePath = file.substr(0, found);
		if (std::find(packageNames.begin(), packageNames.end(), packagePath) != packageNames.end()) {
			/* v contains x */
			//do nothing
		}
		else {
			packageNames.push_back(packagePath);
		}
	}
	return packageNames;	
}

void Browse::printPackageHistory(const PackagePath& packagePath)
{
	cout << "\n It contains the following File Versions:\n";
	std::vector<std::string> files = Directory::getFiles(packagePath);
	for (auto file : files) 
	{
		cout << "     " << file << "\n" ;
	}
}
void Browse::printFullPackageText(const PackagePath& packagePath)
{
	std::vector<std::string> files = Directory::getFiles(packagePath);
	for (size_t i = 0; i < files.size(); ++i) 
	{
		File file(packagePath+"/"+files[i]);
		file.open(File::in);
		if (!file.isGood())
		{
			std::cout << "\n  Can't open file " << file.name();
			std::cout << "\n  Here's what the program can't find:\n  " << Path::getFullFileSpec(file.name());
			continue;
		}
		std::string temp = std::string("Processing file ") + files[i];
		title(temp, '-');
		for (int j = 0; j<10; ++j)
		{
			if (!file.isGood())
				break;
			std::cout << "\n  -- " << file.getLine().c_str();
		}
		std::cout << "\n";
	}
}

#ifdef TEST_BROWSE
int main()
{
	cout << "Tests to test this package individually should be added here...";
    return 0;
}
#endif
