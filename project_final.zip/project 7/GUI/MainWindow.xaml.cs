﻿///////////////////////////////////////////////////////////////////////
// MainWindow.xaml.cs - GUI for Project3HelpWPF                      //
// ver 1.0                                                           //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2018         //
// ver 2.0                                                           //
// Akshay Goyal, CSE687 - Object Oriented Design, Spring 2018        //
///////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package provides a WPF-based GUI for Project3HelpWPF demo.  It's 
 * responsibilities are to:
 * - Provide a display of directory contents of a remote ServerPrototype.
 * - It provides a subdirectory list and a filelist for the selected directory.
 * - You can navigate into subdirectories by double-clicking on subdirectory
 *   or the parent directory, indicated by the name "..".
 *   
 * Required Files:
 * ---------------
 * Mainwindow.xaml, MainWindow.xaml.cs
 * Translater.dll
 * 
 * Maintenance History:
 * --------------------
 * ver 1.0 : 30 Mar 2018
 * - first release
 * - Several early prototypes were discussed in class. Those are all superceded
 *   by this package.
 * ver 2.0 : 8 April 2018
 * - second release
 * - Added code for Project 3.
 */

// Translater has to be statically linked with CommLibWrapper
// - loader can't find Translater.dll dependent CommLibWrapper.dll
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.IO;
using MsgPassingCommunication;

namespace WpfApp1
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private Stack<string> pathStack_ = new Stack<string>();
    private Stack<string> VFpathStack_ = new Stack<string>();
    private Translater translater;
    private CsEndPoint endPoint_;
    private Thread rcvThrd = null;
    private Dictionary<string, Action<CsMessage>> dispatcher_ 
      = new Dictionary<string, Action<CsMessage>>();
    private bool shouldTestDir = true;
    private bool shouldTestFile = true;

    internal string saveFilesPath;

        // method for unit testing
        public void TestCheckin()
    {
            CheckInPackageName.Text = "PackageC";
            //CheckInFolderPath.Text = "../Demo_Project/Checkout";
            CheckInFolderPath.Text = "../DemoCheckout";
            CheckinAuthor.Text = "Akshay";
            CheckinDPNames.Text = "PackageA+PackageB";
            CheckinButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent, CheckinButton));
    }
    public void TestCheckout()
    {
            CheckoutPackageName.Text = "PackageC";
            CheckoutFolderPath.Text = "../DemoCheckout";
            CheckoutButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent, CheckoutButton));
    }
    public void TestBrowse()
    {
            BrowsePaths.Text = "../Demo_Project/Repo_Vault/PackageA/PackageA.h.1+../Demo_Project/Repo_Vault/PackageD/PackageD.cpp.1";
            BrowseButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent, BrowseButton));
    }
    public void TestViewFiles()
    {
            VFDirList.SelectedIndex = 2;
            //VFHelpText.Text = "YAHOOO: " + (string)VFDirList.SelectedItem + ", count " + VFDirList.Items.Count;
            VFGetFilesButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent, VFGetFilesButton));
    }
    public void TestViewFiles2()
    {
            if (VFFileList.Items.Count > 0)
            {
                VFFileList.SelectedIndex = 1;
                shouldTestFile = false;
                VFViewButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent, VFViewButton));
            }
            
    }

        //----< process incoming messages on child thread >----------------

        private void processMessages()
    {
      ThreadStart thrdProc = () => {
        while (true)
        {
          CsMessage msg = translater.getMessage();
          string msgId = msg.value("command");
          if (dispatcher_.ContainsKey(msgId))
            dispatcher_[msgId].Invoke(msg);
        }
      };
      rcvThrd = new Thread(thrdProc);
      rcvThrd.IsBackground = true;
      rcvThrd.Start();
    }

    private void updateBrowseHelpBox(string returnedResult)
    {
            BrowseHelpText.Text = returnedResult;
    }

    private void clearBrowseFields()
    {
            BrowsePaths.Clear();
            BrowseList.Items.Clear();
    }

    private void updateCheckoutHelpBox(string returnedResult)
    {
            CheckoutHelpText.Text = returnedResult;
    }

    private void updateViewFileHelpBox(string returnedResult)
    {
            VFHelpText.Text = returnedResult;
    }

    private void clearCheckoutFields()
    {
            CheckoutPackageName.Clear();
            CheckoutFolderPath.Clear();
    }

        private void updateCheckinHelpBox(string returnedResult)
    {
            CheckinHelpText.Text = returnedResult;
    }

    private void clearCheckinFields()
    {
       CheckInPackageName.Clear();
       CheckInFolderPath.Clear();
       CheckinAuthor.Clear();
       CheckinDPNames.Clear();
    }

        private void addBrowsePackage(string package)
        {
            BrowseList.Items.Add(package);
        }

        //----< function dispatched by child thread to main thread >-------

        private void VFclearDirs()
        {
            VFDirList.Items.Clear();
        }
        //----< function dispatched by child thread to main thread >-------

        private void VFaddDir(string dir)
        {
            VFDirList.Items.Add(dir);
        }

    //----< function dispatched by child thread to main thread >-------

    private void clearDirs()
    {
      DirList.Items.Clear();
    }
    //----< function dispatched by child thread to main thread >-------

    private void addDir(string dir)
    {
      DirList.Items.Add(dir);
    }
    //----< function dispatched by child thread to main thread >-------

    private void insertParent()
    {
      DirList.Items.Insert(0, "..");
    }

        //----< function dispatched by child thread to main thread >-------

        private void VFinsertParent()
        {
            VFDirList.Items.Insert(0, "..");
        }

        //----< function dispatched by child thread to main thread >-------

        private void VFclearFiles()
        {
            VFFileList.Items.Clear();
        }
        //----< function dispatched by child thread to main thread >-------

        private void VFaddFile(string file)
        {
            VFFileList.Items.Add(file);
        }

        //----< function dispatched by child thread to main thread >-------

        private void clearFiles()
    {
      FileList.Items.Clear();
    }
    //----< function dispatched by child thread to main thread >-------

    private void addFile(string file)
    {
      FileList.Items.Add(file);
    }
    //----< add client processing for message with key >---------------

    private void addClientProc(string key, Action<CsMessage> clientProc)
    {
      dispatcher_[key] = clientProc;
    }

        private void DispatcherLoadVFViewFile()
        {
            Action<CsMessage> VFViewFile = (CsMessage rcvMsg) =>
            {
                string returnString = "View File Successful!\n";
                string fileName = "";
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    string value = enumer.Current.Value;
                    //returnString = returnString + "key: " + key;
                    //returnString = returnString + " value: " + value + " | ";
                    if (key.Contains("sendingFile"))
                    {
                        fileName = enumer.Current.Value;
                        break;
                    }
                }
                Action update = () =>
                {
                    updateViewFileHelpBox(returnString);
                };
                Dispatcher.Invoke(update, new Object[] { });
                if (fileName.Length > 0)
                {
                    Action<string> act = (string fileNm) => { showFile(fileNm); };
                    Dispatcher.Invoke(act, new object[] { fileName });
                }
            };
            addClientProc("VFViewFile", VFViewFile);
        }

        private void DispatcherLoadBrowse()
    {
            Action<CsMessage> browse = (CsMessage rcvMsg) =>
            {
                Action clrBrowseFields = () =>
                {
                    clearBrowseFields();
                };
                Dispatcher.Invoke(clrBrowseFields, new Object[] { });
                string returnString = "";
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    string value = enumer.Current.Value;
                    if (key == "result" && value == "true")
                    {
                        returnString = "Browse was successful!";
                    }
                    else if (key == "result" && value == "false")
                    {
                        returnString = "No Packages Found!";
                    }
                    //now populate the browse list
                    if (key.Contains("browse"))
                    {
                        Action<string> doBrowse = (string package) =>
                        {
                            addBrowsePackage(package);
                        };
                        Dispatcher.Invoke(doBrowse, new Object[] { enumer.Current.Value });
                    }
                    //returnString = returnString + "key: " + key;
                    //returnString = returnString + " value: " + value + " | ";
                }
                Action update = () =>
                {
                    updateBrowseHelpBox(returnString);
                };
                Dispatcher.Invoke(update, new Object[] { });
            };
            addClientProc("browse", browse);
    }

    private void DispatcherLoadCheckout()
    {
            Action<CsMessage> checkout = (CsMessage rcvMsg) =>
            {
                Action clrCheckoutFields = () =>
                {
                    clearCheckoutFields();
                };
                Dispatcher.Invoke(clrCheckoutFields, new Object[] { });
                string returnString = "";
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    string value = enumer.Current.Value;
                    if (key == "result" && value == "true") {
                        returnString = "Checkout was successful!";
                    }
                    else if (key == "result" && value == "false")
                    {
                        returnString = "Checkout failed!";
                    }
                    //returnString = returnString + "key: " + key;
                    //returnString = returnString + " value: " + value + " | ";
                }
                Action update = () =>
                {
                    updateCheckoutHelpBox(returnString);
                };
                Dispatcher.Invoke(update, new Object[] { });
            };
            addClientProc("checkout", checkout);
    }

        private void DispatcherLoadCheckin()
    {
            Action<CsMessage> checkin = (CsMessage rcvMsg) =>
            {
                Action clrCheckinFields = () =>
                {
                    clearCheckinFields();
                };
                Dispatcher.Invoke(clrCheckinFields, new Object[] { });
                string returnString = "";
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    string value = enumer.Current.Value;
                    if (key == "result" && value == "true")
                    {
                        returnString = "Checkin was successful!";
                    }
                    else if (key == "result" && value == "false")
                    {
                        returnString = "Checkin failed!";
                    }
                    //returnString = returnString + "key: " + key;
                    //returnString = returnString + " value: " + value + " | ";
                }
                Action update = () =>
                {
                    updateCheckinHelpBox(returnString);
                };
                Dispatcher.Invoke(update, new Object[] { });
            };
            addClientProc("checkin", checkin);
  }


        private void DispatcherLoadVFGetDirs()
        {
            Action<CsMessage> getVFDirs = (CsMessage rcvMsg) =>
            {
                Action VFclrDirs = () =>
                {
                    VFclearDirs();
                };
                Dispatcher.Invoke(VFclrDirs, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("dir"))
                    {
                        Action<string> doDir = (string dir) =>
                        {
                            VFaddDir(dir);
                        };
                        Dispatcher.Invoke(doDir, new Object[] { enumer.Current.Value });
                    }
                }
                Action insertUp = () =>
                {
                    VFinsertParent();
                    if (shouldTestDir == true)
                    {
                        TestViewFiles();
                        shouldTestDir = false;
                    } 
                };
                Dispatcher.Invoke(insertUp, new Object[] { });
            };
            addClientProc("VFgetDirs", getVFDirs);
        }

        //----< load getDirs processing into dispatcher dictionary >-------

    private void DispatcherLoadGetDirs()
    {
      Action<CsMessage> getDirs = (CsMessage rcvMsg) =>
      {
        Action clrDirs = () =>
        {
          clearDirs();
        };
        Dispatcher.Invoke(clrDirs, new Object[] { });
        var enumer = rcvMsg.attributes.GetEnumerator();
        while (enumer.MoveNext())
        {
          string key = enumer.Current.Key;
          if (key.Contains("dir"))
          {
            Action<string> doDir = (string dir) =>
            {
              addDir(dir);
            };
            Dispatcher.Invoke(doDir, new Object[] { enumer.Current.Value });
          }
        }
        Action insertUp = () =>
        {
          insertParent();
        };
        Dispatcher.Invoke(insertUp, new Object[] { });
      };
      addClientProc("getDirs", getDirs);
    }
    //----< load getFiles processing into dispatcher dictionary >------

    private void DispatcherLoadGetFiles()
    {
      Action<CsMessage> getFiles = (CsMessage rcvMsg) =>
      {
        Action clrFiles = () =>
        {
          clearFiles();
        };
        Dispatcher.Invoke(clrFiles, new Object[] { });
        var enumer = rcvMsg.attributes.GetEnumerator();
        while (enumer.MoveNext())
        {
          string key = enumer.Current.Key;
          if (key.Contains("file"))
          {
            Action<string> doFile = (string file) =>
            {
              addFile(file);
            };
            Dispatcher.Invoke(doFile, new Object[] { enumer.Current.Value });
          }
        }
      };
      addClientProc("getFiles", getFiles);
    }


        private void DispatcherLoadVFGetFiles()
        {
            Action<CsMessage> getFiles = (CsMessage rcvMsg) =>
            {
                Action clrFiles = () =>
                {
                    VFclearFiles();
                };
                Dispatcher.Invoke(clrFiles, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("file"))
                    {
                        Action<string> doFile = (string file) =>
                        {
                            VFaddFile(file);
                        };
                        Dispatcher.Invoke(doFile, new Object[] { enumer.Current.Value });
                    }
                }
                Action insertUp = () =>
                {
                    if (shouldTestFile == true)
                        {
                            TestViewFiles2();
                        }
                };
                Dispatcher.Invoke(insertUp, new Object[] { });  
            };
            addClientProc("VFgetFiles", getFiles);
        }

        //----< load all dispatcher processing >---------------------------

        private void loadDispatcher()
    {
      DispatcherLoadGetDirs();
      DispatcherLoadGetFiles();

      DispatcherLoadCheckin();
      DispatcherLoadCheckout();
      DispatcherLoadBrowse();
      DispatcherLoadVFGetDirs();
      DispatcherLoadVFGetFiles();
      DispatcherLoadVFViewFile();
    }
    //----< start Comm, fill window display with dirs and files >------

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // start Comm
      endPoint_ = new CsEndPoint();
      endPoint_.machineAddress = "localhost";
      endPoint_.port = 8082;
      translater = new Translater();
      translater.listen(endPoint_);

      // start processing messages
      processMessages();

      // load dispatcher
      loadDispatcher();

      CsEndPoint serverEndPoint = new CsEndPoint();
      serverEndPoint.machineAddress = "localhost";
      serverEndPoint.port = 8080;

      saveFilesPath = translater.setSaveFilePath("../../../SaveFiles");

      PathTextBlock.Text = "Storage";
      pathStack_.Push("../Storage");
      CsMessage msg = new CsMessage();
      /*msg.add("to", CsEndPoint.toString(serverEndPoint));
      msg.add("from", CsEndPoint.toString(endPoint_));
      msg.add("command", "getDirs");
      msg.add("path", pathStack_.Peek());
      translater.postMessage(msg);
      msg.remove("command");
      msg.add("command", "getFiles");
      translater.postMessage(msg);*/

      //code for view files tab
      VFPath.Text = "Demo_Project";
      VFpathStack_.Push("../Demo_Project/Repo_Vault");
      msg = new CsMessage();
      msg.add("to", CsEndPoint.toString(serverEndPoint));
      msg.add("from", CsEndPoint.toString(endPoint_));
      msg.add("command", "VFgetDirs");
      msg.add("dirpath", VFpathStack_.Peek());
      translater.postMessage(msg);
      msg.remove("command");
      msg.add("command", "VFgetFiles");
      translater.postMessage(msg);

      // calling test methods
      TestCheckout();
      TestCheckin();
      TestBrowse();
      //TestViewFiles();
      //test1();
    }
    //----< strip off name of first part of path >---------------------

    private string removeFirstDir(string path)
    {
      string modifiedPath = path;
      int pos = path.IndexOf("/");
      modifiedPath = path.Substring(pos + 1, path.Length - pos - 1);
      return modifiedPath;
    }

        private string VFremoveFirstDir(string path)
        {
            string modifiedPath = path;
            int pos = path.IndexOf("/");
            modifiedPath = path.Substring(pos + 1, path.Length - pos - 1);
            return modifiedPath;
        }

    //----< respond to mouse double-click on dir name >----------------

    private void DirList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      // build path for selected dir
      string selectedDir = (string)DirList.SelectedItem;
      string path;
      if(selectedDir == "..")
      {
        if (pathStack_.Count > 1)  // don't pop off "Storage"
          pathStack_.Pop();
        else
          return;
      }
      else
      {
        path = pathStack_.Peek() + "/" + selectedDir;
        pathStack_.Push(path);
      }
      // display path in Dir TextBlcok
      PathTextBlock.Text = removeFirstDir(pathStack_.Peek());
      
      // build message to get dirs and post it
      CsEndPoint serverEndPoint = new CsEndPoint();
      serverEndPoint.machineAddress = "localhost";
      serverEndPoint.port = 8080;
      CsMessage msg = new CsMessage();
      msg.add("to", CsEndPoint.toString(serverEndPoint));
      msg.add("from", CsEndPoint.toString(endPoint_));
      msg.add("command", "getDirs");
      msg.add("path", pathStack_.Peek());
      translater.postMessage(msg);
      
      // build message to get files and post it
      msg.remove("command");
      msg.add("command", "getFiles");
      translater.postMessage(msg);
    }

        private void VFDirList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // build path for selected dir
            string selectedDir = (string)VFDirList.SelectedItem;
            VFHelpText.Text = selectedDir;
            string path;
            if (selectedDir == "..")
            {
                if (VFpathStack_.Count > 1)  // don't pop off "Storage"
                    VFpathStack_.Pop();
                else
                    return;
            }
            else
            {
                path = VFpathStack_.Peek() + "/" + selectedDir;
                VFpathStack_.Push(path);
            }
            // display path in Dir TextBlcok
            VFPath.Text = VFremoveFirstDir(VFpathStack_.Peek());

            // build message to get dirs and post it
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;
            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "VFgetDirs");
            msg.add("dirpath", VFpathStack_.Peek());
            translater.postMessage(msg);

            // build message to get files and post it
            msg.remove("command");
            msg.add("command", "VFgetFiles");
            translater.postMessage(msg);
        }

        private void VFFileList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // build message to view the file
            string selectedFile = (string)VFFileList.SelectedItem;
            string path = VFpathStack_.Peek() + "/" + selectedFile;
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;
            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "VFViewFile");
            msg.add("filename", selectedFile);
            msg.add("path", path);
            translater.postMessage(msg);
        }

        //----< first test not completed >---------------------------------

    void test1()
    {
      MouseButtonEventArgs e = new MouseButtonEventArgs(null, 0, 0);
      DirList.SelectedIndex = 1;
      DirList_MouseDoubleClick(this, e);
    }

    private void CheckinButton_Click(object sender, RoutedEventArgs e)
    {
            if (CheckInPackageName.Text == "" || CheckInFolderPath.Text == "" || CheckinAuthor.Text == "")
            {
                CheckinHelpText.Text = "Missing Information...Please fill all fields..";
            }
            else
            {
                // build message to checkin the package
                CsEndPoint serverEndPoint = new CsEndPoint();
                serverEndPoint.machineAddress = "localhost";
                serverEndPoint.port = 8080;
                CsMessage msg = new CsMessage();
                msg.add("to", CsEndPoint.toString(serverEndPoint));
                msg.add("from", CsEndPoint.toString(endPoint_));
                msg.add("command", "checkin");
                msg.add("checkinPackageName", CheckInPackageName.Text);
                msg.add("checkinFolderPath", CheckInFolderPath.Text);
                msg.add("checkinAuthor", CheckinAuthor.Text);
                msg.add("checkinDPNames", CheckinDPNames.Text);
                translater.postMessage(msg);
            }
        }

    private void CheckoutButton_Click(object sender, RoutedEventArgs e)
    {
            if (CheckoutPackageName.Text == "" || CheckoutFolderPath.Text == "")
            {
                CheckoutHelpText.Text = "Missing Information...Please fill all fields..";
            }
            else
            {
                // build message to checkout the package
                CsEndPoint serverEndPoint = new CsEndPoint();
                serverEndPoint.machineAddress = "localhost";
                serverEndPoint.port = 8080;
                CsMessage msg = new CsMessage();
                msg.add("to", CsEndPoint.toString(serverEndPoint));
                msg.add("from", CsEndPoint.toString(endPoint_));
                msg.add("command", "checkout");
                msg.add("CheckoutPackageName", CheckoutPackageName.Text);
                msg.add("CheckoutFolderPath", CheckoutFolderPath.Text);
                translater.postMessage(msg);
            }
        }

    private void BrowseButton_Click(object sender, RoutedEventArgs e)
    {
            if (BrowsePaths.Text == "")
            {
                BrowseHelpText.Text = "Missing Information...Please fill all fields..";
            }
            else
            {
                // build message to checkout the package
                CsEndPoint serverEndPoint = new CsEndPoint();
                serverEndPoint.machineAddress = "localhost";
                serverEndPoint.port = 8080;
                CsMessage msg = new CsMessage();
                msg.add("to", CsEndPoint.toString(serverEndPoint));
                msg.add("from", CsEndPoint.toString(endPoint_));
                msg.add("command", "browse");
                msg.add("BrowsePaths", BrowsePaths.Text);
                translater.postMessage(msg);
            }
    }

        private void VFGetFilesButton_Click(object sender, RoutedEventArgs e)
        {
            // build path for selected dir
            string selectedDir = (string)VFDirList.SelectedItem;
            string path;
            if (selectedDir == "..")
            {
                if (VFpathStack_.Count > 1)  // don't pop off "Storage"
                    VFpathStack_.Pop();
                else
                    return;
            }
            else
            {
                path = VFpathStack_.Peek() + "/" + selectedDir;
                VFpathStack_.Push(path);
            }
            // display path in Dir TextBlcok
            VFPath.Text = VFremoveFirstDir(VFpathStack_.Peek());

            // build message to get dirs and post it
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;
            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "VFgetDirs");
            msg.add("dirpath", VFpathStack_.Peek());
            translater.postMessage(msg);

            // build message to get files and post it
            msg.remove("command");
            msg.add("command", "VFgetFiles");
            translater.postMessage(msg);
        }

        private void VFViewButton_Click(object sender, RoutedEventArgs e)
        {
            // build message to view the file
            string selectedFile = (string)VFFileList.SelectedItem;
            string path = VFpathStack_.Peek() + "/" + selectedFile;
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;
            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "VFViewFile");
            msg.add("path", path);
            msg.add("filename", selectedFile);
            translater.postMessage(msg);
        }

        //----< show file text >-------------------------------------------

        private void showFile(string fileName)
        {
            Console.Write("\n  SHOW FILE");
            Paragraph paragraph = new Paragraph();
            string fileSpec = saveFilesPath + "\\" + fileName;
            Console.Write("\n  fileSpec: " + fileSpec);
            string fileText = File.ReadAllText(fileSpec);
            paragraph.Inlines.Add(new Run(fileText));
            CodePopupWindow popUp = new CodePopupWindow();
            popUp.codeView.Blocks.Clear();
            popUp.codeView.Blocks.Add(paragraph);
            popUp.Show();
        }
    }
}
