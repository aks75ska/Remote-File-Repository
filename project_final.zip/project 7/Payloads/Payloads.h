#pragma once
#ifndef PAYLOADS_H
#define PAYLOADS_H
/////////////////////////////////////////////////////////////////////
// Payloads.h - Defines Payload types for NoSqlDb                  //
// ver 1.0                                                         //
// Akshay Goyal, CSE687 - Object Oriented Design, Spring 2018      //
/////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* This package provides a space to add custom Payload types for a NoSqlDB
* Has defined a class called FileRepositoryPayload, which will be used in project#2
* to store the information about files in a repository

* Required Files:
* ---------------

*
* Maintenance History:
* --------------------
* ver 1.0 : 5 Feb 2018
*/

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>

using namespace std;

namespace Payloads
{

	class FileRepositoryPayload
	{
	
	public:
		using FileLocation = std::string;
		using Categories = std::vector<std::string>;
		
		using FileName = std::string;
		using Version = int;
		using Author = std::string;
		using Description = std::string;
		using CheckinStatus = bool;

		// methods to get and set FileRepositoryPayload fields
		FileLocation& fileLocation() { return fileLocation_; }
		FileLocation fileLocation() const { return fileLocation_; }
		void fileLocation(const FileLocation& fileLocation) { fileLocation_ = fileLocation; }

		Categories& categories() { return categories_; }
		Categories categories() const { return categories_; }
		void categories(const Categories& categories) { categories_ = categories; }

		FileName& fileName() { return fileName_; }
		FileName fileName() const { return fileName_; }
		void fileName(const FileName& fileName) { fileName_ = fileName; }

		Version& version() { return version_; }
		Version version() const { return version_; }
		void version(const Version& version) { version_ = version; }

		Author& author() { return author_; }
		Author author() const { return author_; }
		void author(const Author& author) { author_ = author; }

		Description& description() { return description_; }
		Description description() const { return description_; }
		void description(const Description& description) { description_ = description; }

		CheckinStatus& isClosed() { return isClosed_; }
		CheckinStatus isClosed() const { return isClosed_; }
		void isClosed(const CheckinStatus& isClosed) { isClosed_ = isClosed; }



	private:
		FileLocation fileLocation_;
		Categories categories_;
		FileName fileName_;
		Version version_;
		Author author_;
		Description description_;
		CheckinStatus isClosed_;

	};

	std::ostream& operator<<(std::ostream &stream, const FileRepositoryPayload& givenPayloadObject);

	/*std::ostream& operator<<(std::ostream &stream, const FileRepositoryPayload& givenPayloadObject) {
		std::vector<std::string> categories = givenPayloadObject.categories();
		std::string categoriesString = "";
		for(auto item : categories)
		{
			categoriesString = categoriesString + item + " ";
		}
		return stream << "Location: " << givenPayloadObject.fileLocation() << ", Categories: " << categoriesString << ", version: " 
			<< to_string(givenPayloadObject.version()) << ", isClosed: " << to_string(givenPayloadObject.isClosed());

	}*/

}
#endif