#pragma once
/////////////////////////////////////////////////////////////////////
// Query.h - Defines NoSql database Query operations               //
// ver 1.0                                                         //
// Akshay Goyal, CSE687 - Object Oriented Design, Spring 2018      //
/////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* This package provides a class to handle queries on a NoSqlDb and
* a structure to hold the conditions to be passed to a query
* The functions of the class satisfies the requirements #6 and #7 
* of Project#1

* Required Files:
* ---------------
* DbCore.h, Query.h, Query.cpp
* DateTime.h, DateTime.cpp
* Utilities.h, Utilities.cpp
*
* Maintenance History:
* --------------------
* ver 1.0 : 3 Feb 2018
*/

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <regex>
#include "../DateTime/DateTime.h"
#include "../DbCore/DbCore.h"

using namespace NoSqlDb;
using namespace std;

namespace NoSqlDbQuery
{
	struct Conditions
	{
		std::regex name_ = std::regex("");
		std::regex descrip_ = std::regex("");
		std::regex children_ = std::regex("");
		std::regex payLoad_ = std::regex("");
	};

	template<typename T>
	class Query
	{
	public:
		using Key = std::string;
		using Keys = std::vector<Key>;

		Query(DbCore<T>& dbCore) : dbCore_(dbCore)
		{
			//dbCore_ = dbCore;
			keys_ = dbCore_.keys();
		}
		//this method returns the value of a specific key in the query set if it exists else return an empty DbElement
		DbElement<T> valueForKey(const Key& key) const;

		//this method returns a reference to this object after replacing its keys by the intersection of children of the given key and its original keys
		Query& children(const Key& key);

		//this method returns a reference to this object after replacing its keys by the intersection of keys matching the given regex and its original keys
		Query& regexFilter(const std::regex& givenRegex);

		//this method returns a reference to this object after replacing its keys by the intersection of keys having the given regex in their meta data and its
		//original keys
		Query& select(const Conditions& conditions);

		//this method returns a reference to this object after replacing its keys by the intersection of keys having datetime within the secified interval
		//and its original keys
		Query& dateFilter(const DateTime& dateTime_start = DateTime().now(), const DateTime& dateTime_end = DateTime().now());

		//this method returns the reference to this object after replacing its keys by the given keys 
		Query& from(Keys& keys);

		//this method returns the reference to this object after replacing its keys with union of keys of this object and the given object
		Query& unionWith(Query& givenQuery);

		//this method prints the keys of this object on screen
		void show();

		//this method returns the keys of this object
		Keys keys() { return keys_; };

	private:
		DbCore<T>& dbCore_;
		Keys keys_;

		//this is a private generic method which takes two vectors and returns their intersection
		std::vector<string> intersection(vector<string> &v1, vector<string> &v2);

		//this is a private generic method which takes a vector of strings and a regex and tells if regex matches any one string
		bool regexMatchInVector(vector<string> &v, const std::regex& givenRegex);
	};

	//this is a private generic method which takes a vector of strings and a regex and tells if regex matches any one string
	template<typename T>
	bool Query<T>::regexMatchInVector(vector<string> &v, const std::regex& givenRegex)
	{
		for (auto item : v)
		{
			if (std::regex_match(item, givenRegex))
			{
				return true;
			}
		}
		return false;
	}

	//this is a generic method which takes two vectors and returns their intersection
	template<typename T>
	std::vector<string> Query<T>::intersection(vector<string> &v1, vector<string> &v2)
	{
		vector<string> v3;
		sort(v1.begin(), v1.end());
		sort(v2.begin(), v2.end());
		set_intersection(v1.begin(), v1.end(), v2.begin(), v2.end(), back_inserter(v3));

		return v3;
	}

	//this method returns the value of a specific key in the query set if it exists else return an empty DbElement
	template<typename T>
	DbElement<T> Query<T>::valueForKey(const Key& key) const
	{
		return dbCore_[key];
	}

	//this method returns a reference to this object after replacing its keys by the intersection of children of the given key and its original keys
	template<typename T>
	Query<T>& Query<T>::children(const Key& key)
	{
		keys_ = intersection(keys_, dbCore_[key].children());
		return *this;
	}

	//this method returns a reference to this object after replacing its keys by the intersection of keys matching the given regex and its original keys
	template<typename T>
	Query<T>& Query<T>::regexFilter(const std::regex& givenRegex)
	{
		vector<string> filteredKeys;
		for (auto item : keys_)
		{
			if (std::regex_match(item, givenRegex))
			{
				filteredKeys.push_back(item);
			}
		}

		keys_ = filteredKeys;
		return *this;
	}

	//this method returns a reference to this object after replacing its keys by the intersection of keys having the given regex in their meta data and its
	//original keys
	template<typename T>
	Query<T>& Query<T>::select(const Conditions& conditions)
	{
		vector<string> filteredKeys;
		for (auto item : keys_)
		{
			DbElement<T> thisValue = dbCore_[item];
			vector<string> thisValuesChildren = thisValue.children();
			if (std::regex_match("", conditions.name_) || (!std::regex_match("", conditions.name_) && std::regex_match(thisValue.name(), conditions.name_)))
			{
				if (std::regex_match("", conditions.descrip_) || (!std::regex_match("", conditions.descrip_) && std::regex_match(thisValue.descrip(), conditions.descrip_)))
				{
					if (std::regex_match("", conditions.children_) || (!std::regex_match("", conditions.children_) && regexMatchInVector(thisValuesChildren, conditions.children_)))
					{
						if (std::regex_match("", conditions.payLoad_) || (!std::regex_match("", conditions.payLoad_) && std::regex_match(thisValue.payLoad(), conditions.payLoad_)))
						{
							filteredKeys.push_back(item);
						}
					}

				}

			}
		}

		keys_ = filteredKeys;
		return *this;
	}


	//this method returns a reference to this object after replacing its keys by the intersection of keys having datetime within the secified interval
	//and its original keys
	template<typename T>
	Query<T>& Query<T>::dateFilter(const DateTime& dateTime_start, const DateTime& dateTime_end)
	{
		vector<string> filteredKeys;
		for (auto item : keys_)
		{
			DbElement<T> thisValue = dbCore_[item];
			if (thisValue.dateTime() > dateTime_start && thisValue.dateTime() < dateTime_end)
			{
				filteredKeys.push_back(item);
			}
		}

		keys_ = filteredKeys;
		return *this;
	}

	//this method returns the reference to this object after replacing its keys by the given keys 
	template<typename T>
	Query<T>& Query<T>::from(Keys& keys)
	{
		keys_ = keys;
		return *this;
	}

	//this method prints the keys of this object on screen
	template<typename T>
	void Query<T>::show()
	{
		cout << "\n  ";
		for (auto key : keys_)
		{
			cout << key << " ";
		}
	}

	//this method returns the reference to this object after replacing its keys with union of keys of this object and the given object
	template<typename T>
	Query<T>& Query<T>::unionWith(Query& givenQuery)
	{
		vector<std::string> v3;
		vector<std::string> temp = givenQuery.keys();
		sort(keys_.begin(), keys_.end());
		sort(temp.begin(), temp.end());
		set_union(keys_.begin(), keys_.end(), temp.begin(), temp.end(), back_inserter(v3));

		keys_ = v3;
		return *this;
	}

}