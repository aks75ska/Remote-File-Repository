#pragma once
/////////////////////////////////////////////////////////////////////
// RepositoryCore.h - provides means to check-in, version, browse  //
// and check-out source code packages.                             //
// ver 1.0                                                         //
// Akshay Goyal, CSE687 - Object Oriented Design, Spring 2018      //
/////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* it contains one class RepositoryCore
* RepositoryCore implements the basic functioning of a File Repository core
* it provides means to check-in, version, browse, and check-out source code packages.


* Required Files:
* ---------------
../DbCore/DbCore.h, ../CheckIn/CheckIn.h, ../CheckOut/CheckOut.h
../Browse/Browse.h
*
* Maintenance History:
* --------------------
* ver 1.0 : 1 Mar 2018
*
* --------------------
* Notes >---<
* we can add more methods to RepositoryCore like
* method to initialze an existing repository which will take the path to root just like createRepository
* and then it will try to find the corresponding XML db file which we will provide
* from that xml, it will recreate the DbCore. But I have not done it as part of P2 because constructing Payload from xml
* will be tricky and it wasn't mentioned in the requirements

* for above to be successful, we need to do the following as well
* we need to add methods to create and update DBXML file after every operation
*/

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>

#include "../DbCore/DbCore.h"

#include "../CheckIn/CheckIn.h"
#include "../CheckOut/CheckOut.h"
#include "../Browse/Browse.h"

using namespace std;
using namespace NoSqlDb;

namespace RepositoryCoreClasses {

	class RepositoryCore {

		public:
			using RepositoryRoot = std::string;
			using PackageName = std::string;
			using DependantPackages = std::vector<std::string>;
			using AuthorName = std::string;
			using PackagePath = std::string;
			using DestinationPath = std::string;
			using FilePaths = std::vector<std::string>;

			RepositoryRoot& repositoryRootPath() { return repositoryRootPath_; }
			RepositoryRoot repositoryRootPath() const { return repositoryRootPath_; }

			//methods to perform basic repository functions like checkin, checkout, browse and create repo
			bool createRepository(const RepositoryRoot& repositoryRootPath);
			bool checkin(const PackageName& packageName, const DependantPackages& dependantPackages, const AuthorName& authorName, const PackagePath& packagePath);
			bool checkout(const PackageName& packageName, const DestinationPath& destinationPath);
			std::vector<std::string> browse(const FilePaths& FilePaths);

			//this method will print the underlying db to the console
			void showDB();

			//methods to get the underlying db
			DbCore<FileRepositoryPayload>& getDB() { return db; }
			DbCore<FileRepositoryPayload> getDB() const { return db; }


		private:
			RepositoryRoot repositoryRootPath_;
			DbCore<FileRepositoryPayload> db;
			void repositoryRootPath(const RepositoryRoot& repositoryRootPath) { repositoryRootPath_ = repositoryRootPath; }


	};

}